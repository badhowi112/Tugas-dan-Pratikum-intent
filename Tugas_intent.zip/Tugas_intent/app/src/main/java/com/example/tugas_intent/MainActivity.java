package com.example.tugas_intent;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;


public class MainActivity extends AppCompatActivity {
    public static final String EXTRA_MESSAGE = "com.example.tugas_intent.extra.MESSAGE";
    private EditText mMessageEditText,mMessageEditTextAlamat,mMessageEditTextTelephon;
    private static final String LOG_TAG = MainActivity.class.getSimpleName();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mMessageEditText = (EditText) findViewById(R.id.editText);
        mMessageEditTextAlamat = (EditText) findViewById(R.id.editText_Alamat);
        mMessageEditTextTelephon = (EditText) findViewById(R.id.editNoTelp);
    }

    public void gotolink2(View view) {
        Log.d(LOG_TAG, "Button diklik");
        Intent intent = new Intent(this,link2.class);
        String message1 = mMessageEditText.getText().toString();
        String message2 = mMessageEditTextAlamat.getText().toString();
        String message3 = mMessageEditTextTelephon.getText().toString();
        intent.putExtra(EXTRA_MESSAGE, "Nama: "+message1+
                "\nAlamat: "+message2+"\nNo hp: "+message3);
        startActivity(intent);

    }
}
