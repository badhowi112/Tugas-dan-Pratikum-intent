package com.example.intent;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.util.Log;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    public EditText mMessageEditText;

    public static final String EXTRA_MESSAGE = "com.exmple.asus.intent.extra.MESSAGE";

    private static final String LOG_TAG = MainActivity.class.getSimpleName();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mMessageEditText = (EditText) findViewById(R.id.editText_main);
        mMessageEditText = (EditText) findViewById(R.id.editText_main1);
        mMessageEditText = (EditText) findViewById(R.id.editText_main2);
    }

    public void LaunchSecondActivity(View view) {
        Log.d(LOG_TAG, "Buttom diklik");
        Intent intent = new Intent(this, SecondActivity.class);
        String message = mMessageEditText.getText().toString();
        String message1 = mMessageEditText.getText().toString();
        String message2 = mMessageEditText.getText().toString();
        intent.putExtra(EXTRA_MESSAGE,"Nama: "+message+
                "\nAlamat: "+ message1+"\nNo hp: "+message2);

        startActivity(intent);
    }
}
